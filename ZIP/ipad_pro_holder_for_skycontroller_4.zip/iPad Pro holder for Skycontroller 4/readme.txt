 ——————————————————————————————
| Skycontroller 4 iPad Support |
 ——————————————————————————————


REQUIREMENTS
- - - - - - -

The 3D file is composed of three modules.
Depending on the size of your iPad Pro (11’’ or 12,9’’), attach the modules as presented on the .STEP file.
For that, you will need six 16mm (0.6’’) screws.

To maintain the iPad Pro into the rails, you need to add 1mm-thick (0.04’’-thick) foam.
